package VezbiCasZad6;

public class Proizvod {
	String ime;
	int tezina;
	int cena;
	
	public Proizvod () {
		this.ime = "Portokali";
		this.tezina = 3;
		this.cena = 100;
	}
}