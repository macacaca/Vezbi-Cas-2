package VezbiCasZad6;

public class Main {
	public static void main(String[] args) {
		Proizvod object1 = new Proizvod ();
		
		System.out.println("Cenata na " + object1.ime + "te so tezhina od " + object1.tezina + "kg iznesuva " + object1.cena + " denari.");
	}
}