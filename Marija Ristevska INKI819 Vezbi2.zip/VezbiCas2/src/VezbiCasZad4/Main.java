package VezbiCasZad4;

public class Main {
	public static void main(String[] args) {
		Avtomobil object1 = new Avtomobil();
		
		object1.marka = "Mercedes";
		object1.model = "CLS";
		object1.kilometraza = 70000;
		
		Avtomobil object2 = new Avtomobil ("Audi", "Q5", 80000);
		
		System.out.println(object1.marka + " " + object1.model + " " +object1.kilometraza);
		System.out.println(object2.marka + " " + object2.model + " " +object2.kilometraza);
	}
}