package VezbiCasZad4;

public class Avtomobil {
	public String marka;
	public String model;
	public int kilometraza;
	
	public Avtomobil () {
		
	}
	
	public Avtomobil (String marka, String model, int kilometraza) {
		this.marka = marka;
		this.model = model;
		this.kilometraza = kilometraza;
	}
}