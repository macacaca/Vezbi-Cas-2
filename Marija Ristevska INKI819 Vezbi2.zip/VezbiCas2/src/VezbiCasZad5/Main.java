package VezbiCasZad5;

public class Main {
	public static void main(String[] args) {

		Predmet object1 = new Predmet ();				
		
		Predmet object2 = new Predmet ("E vlada i E upravuvanje");

		Predmet object3 = new Predmet ("OOP", "Ilija Joleski", 6);
		
		object1.ime = " Digitalna logika i sistemi";
		object1.profesor = "Nikola Rendevski";
		object1.krediti = 6;
		object1.semestar = "I-vi";
		
		System.out.println(object1.ime + " " + object1.profesor + " " + object1.krediti + " " + object1.semestar);
		System.out.println(object2.ime);
		System.out.println(object3.ime + " " + object3.profesor + " " + object3.krediti);
	}
}
