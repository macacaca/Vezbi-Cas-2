package VezbiCasZad3;

public class Main {
	public static void main (String[] args) {
		Covek object1 = new Covek();
		
		object1.ime = "Marija";
		object1.prezime = "Ristevska";
		object1.mBroj = "0808200236547";
		
		System.out.println("Imeto na covekot e: " + object1.ime + ".");
		System.out.println("Prezimeto na covekot e: " + object1.prezime + ".");
		System.out.println("Cvekot ima maticen broj: " + object1.mBroj + ".");
	}
}